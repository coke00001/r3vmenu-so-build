/*
           Author: R3v
    Mail: R3v10086@outlook.com
     Date: 2026-03-13 12:33:21
      Copyright (c) 2026 R3v
    SPDX-License-Identifier: MIT
*/

struct {
    bool 无敌 = false;
    bool 飞行模式 = false;
    bool 老虎驾驶 = false;
    bool 磁铁效果 = false;
    bool 游泳模式 = false;

    int 金币数量 = 1;
    int 分数数量 = 1;
    int 人物生命 = 999;

    float 距离数量 = 1.0f;
    float 游戏时间 = 1.0f;
    float 移动速度 = 999.0f;
    float 速度上限 = 999.0f;
    float 左右速度 = 999.0f;
    float 跳跃速度 = 999.0f;
    float 无敌时间 = 999.0f;
    float 飞行速度 = 999.0f;
    float 飞行重力 = 0.0f;
    float 飞行时间 = 999.0f;

    int 飞行类型 = 1;
    int 死亡模式 = 0;
} FunctionState;

struct {
    bool 启用VIP = false;

    float 金币加成 = 1.0f;
    float 分数加成 = 1.0f;
    float 道具时间加成 = 1.0f;
    float 宝箱数量加成 = 1.0f;

    bool 强制VIP = false;
    bool 无限领取 = false;

    bool (*orig_IsVip)(Il2CppObject*) = nullptr;
    int (*orig_GetVipLevel)(Il2CppObject*) = nullptr;
    bool (*orig_IsTodayCanGetDailyReward)(Il2CppObject*) = nullptr;
} VipState;

static Il2CppObject* PlayerDuiXiang = nullptr;

bool VipHook_IsVip(Il2CppObject* instance) {
    if (VipState.强制VIP && VipState.启用VIP) return true;
    return VipState.orig_IsVip ? VipState.orig_IsVip(instance) : false;
}

int VipHook_GetVipLevel(Il2CppObject* instance) {
    if (VipState.启用VIP) return 1;
    return VipState.orig_GetVipLevel ? VipState.orig_GetVipLevel(instance) : 0;
}

bool VipHook_IsTodayCanGetDailyReward(Il2CppObject* instance) {    
    if (VipState.无限领取 && VipState.启用VIP) return true;
    return VipState.orig_IsTodayCanGetDailyReward ? VipState.orig_IsTodayCanGetDailyReward(instance) : false;
}

void VipInstallHooks() {
    auto* vipClass = VipManager::GetVipClass();
    if (!vipClass) return;
    if (!VipState.orig_IsVip) {
        auto method = vipClass->getMethod("IsVip");
        if (method && method->methodPointer) {
            VipState.orig_IsVip = (bool(*)(Il2CppObject*))method->replace(VipHook_IsVip);
        }
    }

    if (!VipState.orig_GetVipLevel) {
        auto method = vipClass->getMethod("get_m_VipLevel");
        if (method && method->methodPointer) {
            VipState.orig_GetVipLevel = (int(*)(Il2CppObject*))method->replace(VipHook_GetVipLevel);
        }
    }

    if (!VipState.orig_IsTodayCanGetDailyReward) {
        auto method = vipClass->getMethod("IsTodayCanGetDailyReward");
        if (method && method->methodPointer) {
            VipState.orig_IsTodayCanGetDailyReward = (bool(*)(Il2CppObject*))method->replace(VipHook_IsTodayCanGetDailyReward);
        }
    }
}

void R3vMain() {
    ImGui::SetNextWindowSize(ImVec2(420, 520), ImGuiCond_FirstUseEver);
    ImGui::PushStyleVar(ImGuiStyleVar_WindowBorderSize, 0.0f);
    if (ImGui::Begin("R3v - CheatTest", nullptr, ImGuiWindowFlags_None)) {
        ImGui::Text("R3v | R3v10086@outlook.com");
        ImGui::Text("开源项目");
        bool isAttached = Il2cpp::EnsureAttached();
        if (!PlayerDuiXiang) {
            PlayerDuiXiang = PlayerManager::GetPlayerInstance();
        }
        if (!PlayerDuiXiang || !PlayerManager::IsValidPlayer(PlayerDuiXiang)) {
            PlayerDuiXiang = nullptr;
            ImGui::TextColored(ImVec4(1,0,0,1), "未获取到玩家实例");
            if (ImGui::Button("重新获取")) {
                PlayerDuiXiang = PlayerManager::GetPlayerInstance();
            }
            ImGui::End();
            ImGui::PopStyleVar();
            return;
        }

        if (ImGui::CollapsingHeader("玩家功能", ImGuiTreeNodeFlags_None)) {
            ImGui::SeparatorText("无敌模式");
            ImGui::Checkbox("启用无敌", &FunctionState.无敌);
            ImGui::SameLine();
            ImGui::SetNextItemWidth(180);
            ImGui::InputFloat("无敌时间", &FunctionState.无敌时间);
            FunctionState.无敌时间 = ClampValue(FunctionState.无敌时间, 0.0f, 9999999.0f);
            if (ImGui::Button("开启无敌")) {
                CallMethod<void>(PlayerDuiXiang, "SetInvincible", FunctionState.无敌时间);
                WriteField<bool>(PlayerDuiXiang, "invincible", true);
                WriteField<float>(PlayerDuiXiang, "invincibleTime", FunctionState.无敌时间);
                FunctionState.无敌 = true;
            }
            ImGui::SameLine();
            if (ImGui::Button("关闭无敌")) {
                WriteField<bool>(PlayerDuiXiang, "invincible", false);
                WriteField<float>(PlayerDuiXiang, "invincibleTime", 0.0f);
                FunctionState.无敌 = false;
            }
            ImGui::SeparatorText("移动速度");
            ImGui::SetNextItemWidth(180);
            ImGui::InputFloat("移动速度", &FunctionState.移动速度);
            FunctionState.移动速度 = ClampValue(FunctionState.移动速度, 0.0f, 99999.0f);
            ImGui::SameLine();
            ImGui::SetNextItemWidth(180);
            ImGui::InputFloat("速度上限", &FunctionState.速度上限);
            FunctionState.速度上限 = ClampValue(FunctionState.速度上限, 0.0f, 999999.0f);
            if (ImGui::Button("应用速度")) {
                WriteField<float>(PlayerDuiXiang, "speed", FunctionState.移动速度);
                WriteField<float>(PlayerDuiXiang, "speedMax", FunctionState.速度上限);
            }
            ImGui::SetNextItemWidth(180);
            ImGui::InputFloat("左右速度", &FunctionState.左右速度);
            FunctionState.左右速度 = ClampValue(FunctionState.左右速度, 0.0f, 99999.0f);
            ImGui::SameLine();
            ImGui::SetNextItemWidth(180);
            ImGui::InputFloat("跳跃速度", &FunctionState.跳跃速度);
            FunctionState.跳跃速度 = ClampValue(FunctionState.跳跃速度, 0.0f, 99999.0f);
            if (ImGui::Button("应用左右速度")) {
                WriteField<float>(PlayerDuiXiang, "shiftSpeed", FunctionState.左右速度);
            }
            ImGui::SameLine();
            if (ImGui::Button("应用跳跃速度")) {
                WriteField<float>(PlayerDuiXiang, "jumpSpeed", FunctionState.跳跃速度);
            }
            ImGui::SeparatorText("属性修改");
            float lifeFloat = (float)FunctionState.人物生命;
            ImGui::SetNextItemWidth(180);
            ImGui::InputFloat("人物生命", &lifeFloat);
            lifeFloat = ClampValue(lifeFloat, -99999.0f, 99999.0f);
            FunctionState.人物生命 = (int)lifeFloat;
            ImGui::SameLine();
            if (ImGui::Button("修改生命")) {
                WriteField<int>(PlayerDuiXiang, "_life", FunctionState.人物生命);
            }
        }

        if (ImGui::CollapsingHeader("局内功能", ImGuiTreeNodeFlags_None)) {
            ImGui::SeparatorText("飞行模式");
            ImGui::SetNextItemWidth(180);
            ImGui::InputFloat("飞行速度", &FunctionState.飞行速度);
            FunctionState.飞行速度 = ClampValue(FunctionState.飞行速度, 0.0f, 99999.0f);
            ImGui::SameLine();
            ImGui::SetNextItemWidth(180);
            ImGui::InputFloat("飞行重力", &FunctionState.飞行重力);
            FunctionState.飞行重力 = ClampValue(FunctionState.飞行重力, -999.0f, 999.0f);
            ImGui::SetNextItemWidth(180);
            ImGui::InputFloat("飞行时间", &FunctionState.飞行时间);
            FunctionState.飞行时间 = ClampValue(FunctionState.飞行时间, 0.0f, 9999999.0f);
            ImGui::SameLine();
            const char* flyTypes[] = { "类型 1", "类型 2" };
            int currentFlyType = (FunctionState.飞行类型 >= 1 && FunctionState.飞行类型 <= 2) ? FunctionState.飞行类型 - 1 : 0;
            ImGui::SetNextItemWidth(180);
            if (ImGui::Combo("飞行类型", &currentFlyType, flyTypes, IM_ARRAYSIZE(flyTypes))) {
                FunctionState.飞行类型 = currentFlyType + 1;
            }
            if (ImGui::Button("开始飞行")) {
                CallMethod<void>(PlayerDuiXiang, "StartFly", FunctionState.飞行速度, FunctionState.飞行重力, FunctionState.飞行时间, FunctionState.飞行类型);
            }
            ImGui::SameLine();
            if (ImGui::Button("结束飞行")) {
                CallMethod<void>(PlayerDuiXiang, "EndFly");
            }
            ImGui::SeparatorText("老虎驾驶");
            if (ImGui::Button("开启老虎")) {
                CallMethod<void>(PlayerDuiXiang, "StartTigerDrive", true);
                FunctionState.老虎驾驶 = true;
            }
            ImGui::SameLine();
            if (ImGui::Button("关闭老虎")) {
                CallMethod<void>(PlayerDuiXiang, "EndDriverTiger");
                FunctionState.老虎驾驶 = false;
            }
            ImGui::SeparatorText("磁铁效果");
            if (ImGui::Button("启动磁铁")) {
                CallMethod<void>(PlayerDuiXiang, "StartMagnet");
                FunctionState.磁铁效果 = true;
            }
            ImGui::SameLine();
            if (ImGui::Button("停止磁铁")) {
                CallMethod<void>(PlayerDuiXiang, "StopMagnet");
                FunctionState.磁铁效果 = false;
            }
            ImGui::SeparatorText("游泳模式");
            if (ImGui::Button("进入游泳")) {
                CallMethod<void>(PlayerDuiXiang, "StartSwimRoadMode");
                FunctionState.游泳模式 = true;
            }
            ImGui::SameLine();
            if (ImGui::Button("退出游泳")) {
                CallMethod<void>(PlayerDuiXiang, "ExitSwimRoadMode");
                FunctionState.游泳模式 = false;
            }
            ImGui::SeparatorText("分数修改");
            float scoreFloat = (float)FunctionState.分数数量;
            ImGui::SetNextItemWidth(180);
            ImGui::InputFloat("分数数量", &scoreFloat);
            scoreFloat = ClampValue(scoreFloat, -999999.0f, 9999999.0f);
            FunctionState.分数数量 = (int)scoreFloat;
            ImGui::SameLine();
            if (ImGui::Button("修改分数")) {
                WriteField<int>(PlayerDuiXiang, "score", FunctionState.分数数量);
            }
            ImGui::SameLine();
            if (ImGui::Button("增加分数")) {
                int addScore = ClampValue(FunctionState.分数数量, -999999, 999999);
                CallMethod<void>(PlayerDuiXiang, "AddScore", addScore);
            }
            ImGui::SetNextItemWidth(180);
            ImGui::InputFloat("距离数量", &FunctionState.距离数量);
            FunctionState.距离数量 = ClampValue(FunctionState.距离数量, 0.0f, 9999999.0f);
            ImGui::SameLine();
            if (ImGui::Button("修改距离")) {
                WriteField<float>(PlayerDuiXiang, "distance", FunctionState.距离数量);
            }
            ImGui::SetNextItemWidth(180);
            ImGui::InputFloat("游戏时间", &FunctionState.游戏时间);
            FunctionState.游戏时间 = ClampValue(FunctionState.游戏时间, 0.0f, 9999999.0f);
            ImGui::SameLine();
            if (ImGui::Button("修改时间")) {
                CallMethod<void>(PlayerDuiXiang, "set_RunTime", FunctionState.游戏时间);
            }
            float coinFloat = (float)FunctionState.金币数量;
            ImGui::SetNextItemWidth(180);
            ImGui::InputFloat("金币数量", &coinFloat);
            coinFloat = ClampValue(coinFloat, -999999.0f, 9999999.0f);
            FunctionState.金币数量 = (int)coinFloat;
            ImGui::SameLine();
            if (ImGui::Button("修改金币")) {
                WriteField<int>(PlayerDuiXiang, "coin", FunctionState.金币数量);
            }
            ImGui::SameLine();
            if (ImGui::Button("增加金币")) {
                int addAmount = ClampValue(FunctionState.金币数量, -999999, 999999);
                CallMethod<void>(PlayerDuiXiang, "AddCoin", addAmount);
            }
        }

        if (ImGui::CollapsingHeader("死亡控制", ImGuiTreeNodeFlags_None)) {
            const char* deadModes[] = { "撞头", "坠落", "夹子", "地鼠", "溺水", "泥潭", "世界杯" };
            FunctionState.死亡模式 = ClampValue(FunctionState.死亡模式, 0, 6);
            ImGui::Combo("死亡模式", &FunctionState.死亡模式, deadModes, IM_ARRAYSIZE(deadModes));
            if (ImGui::Button("立即死亡")) {
                CallMethod<void>(PlayerDuiXiang, "SetDead", FunctionState.死亡模式);
            }
        }

        if (ImGui::CollapsingHeader("VIP功能", ImGuiTreeNodeFlags_None)) {
            auto instance = VipManager::GetInstance();
            if (!instance) {
                ImGui::TextColored(ImVec4(1,0,0,1), "未获取到VIP管理器");
                if (ImGui::Button("重新获取VIP管理器")) {
                    VipManager::ResetInstance();
                    VipManager::GetInstance();
                }
            }
            ImGui::SeparatorText("VIP状态");
            ImGui::Checkbox("启用VIP", &VipState.启用VIP);
            ImGui::SeparatorText("VIP Hook功能");
            ImGui::Checkbox("强制VIP", &VipState.强制VIP);
            ImGui::SameLine();
            ImGui::Checkbox("无限领取", &VipState.无限领取);
            ImGui::SeparatorText("VIP加成设置");
            ImGui::SetNextItemWidth(150);
            ImGui::InputFloat("金币加成", &VipState.金币加成);
            VipState.金币加成 = ClampValue(VipState.金币加成, 0.0f, 10000.0f);
            ImGui::SameLine();
            if (ImGui::Button("应用") && instance) {
                WriteField<float>(instance, "m_CoinAdd", VipState.金币加成);
            }
            ImGui::SetNextItemWidth(150);
            ImGui::InputFloat("分数加成", &VipState.分数加成);
            VipState.分数加成 = ClampValue(VipState.分数加成, 0.0f, 10000.0f);
            ImGui::SameLine();
            if (ImGui::Button("应用") && instance) {
                WriteField<float>(instance, "m_ScoreAdd", VipState.分数加成);
            }
            ImGui::SetNextItemWidth(150);
            ImGui::InputFloat("道具时间", &VipState.道具时间加成);
            VipState.道具时间加成 = ClampValue(VipState.道具时间加成, 0.0f, 10000.0f);
            ImGui::SameLine();
            if (ImGui::Button("应用") && instance) {
                WriteField<float>(instance, "m_PropTimeAdd", VipState.道具时间加成);
            }
            ImGui::SetNextItemWidth(150);
            ImGui::InputFloat("宝箱数量", &VipState.宝箱数量加成);
            VipState.宝箱数量加成 = ClampValue(VipState.宝箱数量加成, 0.0f, 100.0f);
            ImGui::SameLine();
            if (ImGui::Button("应用") && instance) {
                WriteField<float>(instance, "m_BoxNumAdd", VipState.宝箱数量加成);
            }
            if (ImGui::Button("应用所有加成") && instance) {
                VipManager::ApplyBonuses(VipState.金币加成, VipState.分数加成, VipState.道具时间加成, VipState.宝箱数量加成);
            }
            ImGui::SeparatorText("VIP每日奖励");
            if (instance) {
                if (ImGui::Button("领取VIP每日奖励")) {
                    VipManager::ClaimDailyReward();
                }
            }
        }

        if (ImGui::CollapsingHeader("资源管理", ImGuiTreeNodeFlags_None)) {
            static Il2CppClass* itemDropMgrClass = nullptr;
            if (!itemDropMgrClass) {
                auto& images = Il2cpp::GetImages();
                for (auto image : images) {
                    itemDropMgrClass = image->getClass("ItemDropMgr");
                    if (itemDropMgrClass) break;
                }
            }
            static Il2CppObject* itemManagerInstance = nullptr;
            static std::vector<std::pair<int, const char*>> itemList = {
                {1, "钻石 (Diamond)"},
                {2, "金币 (Coin)"},
                {3, "护盾 (Shield)"},
                {4, "双倍金币 (DoubleCoin)"},
                {11, "宠物技能 (Pet_Skill)"},
                {20, "磁铁 (Magnet)"},
                {21, "坐骑碎片 (RideShard)"},
                {30, "小白宠物 (PetXiaobai)"},
                {31, "宠物1 (Pet1)"},
                {32, "宠物2 (Pet2)"},
                {33, "宠物3 (Pet3)"},
                {49, "宠物最大 (PetMax)"},
                {51, "碎片1 (Suipian1)"},
                {52, "碎片2 (Suipian2)"},
                {53, "碎片3 (Suipian3)"},
                {54, "碎片4 (Suipian4)"},
                {55, "碎片5 (Suipian5)"},
                {56, "碎片6 (Suipian6)"},
                {57, "碎片7 (Suipian7)"},
                {58, "碎片8 (Suipian8)"},
                {59, "碎片9 (Suipian9)"},
                {60, "碎片10 (Suipian10)"},
                {70, "宠物网 (PetNet)"},
                {71, "鱼1 (Fish1)"},
                {72, "鱼2 (Fish2)"},
                {73, "鱼3 (Fish3)"},
                {74, "鱼4 (Fish4)"},
                {75, "鱼5 (Fish5)"},
                {76, "鱼6 (Fish6)"},
                {100, "角色1 (Role1)"},
                {101, "角色2 (Role2)"},
                {102, "角色3 (Role3)"},
                {103, "角色4 (Role4)"},
                {104, "角色5 (Role5)"},
                {150, "技能 (Skill)"},
                {201, "玩具卡1 (ToyCard1)"},
                {202, "玩具卡2 (ToyCard2)"},
                {203, "玩具卡3 (ToyCard3)"},
                {204, "玩具卡4 (ToyCard4)"},
                {240, "体力 (Physical)"},
                {800, "复活 (Resurrect)"},
                {801, "抽奖 (Lottery)"},
                {802, "免费游戏 (Free_Game)"},
                {803, "VIP"},
                {804, "关卡星星 (Level_Star)"},
                {805, "汽车 (Car)"},
                {806, "炸弹 (Boomb)"},
                {807, "草地 (Grass)"},
                {900, "皮肤起始 (Skin_Start)"},
                {930, "骑手起始 (Rider_Start)"},
                {960, "雪板 (Snow_Board)"},
                {1000, "双倍攻击 (DoubleAttack)"},
                {1001, "生命恢复 (HpRecover)"},
                {1002, "一击必杀 (YiJiBiSha)"},
                {1003, "炮竹 (PAOZHU)"},
                {1020, "卷轴起始 (ReelStart)"},
                {1040, "碎片起始 (FragmentStart)"},
                {1100, "武器起始 (WeaponStart)"},
                {1150, "游戏关卡 (GameLevel)"},
                {1160, "蛋 (Egg)"}
            };
            static int selectedItemIndex = 1;
            static int itemAddCount = 1;
            static char customItemIdStr[32] = "1";
            static bool useCustomId = false;
            if (!itemManagerInstance) {
                itemManagerInstance = ItemManager::GetInstance();
            }
            if (!itemDropMgrClass) {
                ImGui::TextColored(ImVec4(1,0,0,1), "未找到 ItemDropMgr 类");
            } else {
                static int 食物蜂蜜 = 0;
                static int 食物苹果 = 0;
                ImGui::SeparatorText("食物资源");
                ImGui::SetNextItemWidth(180);
                ImGui::InputInt("食物蜂蜜", &食物蜂蜜);
                食物蜂蜜 = ClampValue(食物蜂蜜, -999999, 9999999);
                ImGui::SameLine();
                if (ImGui::Button("添加蜂蜜")) {
                    CallStaticMethod<void>(itemDropMgrClass, "SetFoodHoney", 食物蜂蜜);
                }
                ImGui::SetNextItemWidth(180);
                ImGui::InputInt("食物苹果", &食物苹果);
                食物苹果 = ClampValue(食物苹果, -999999, 9999999);
                ImGui::SameLine();
                if (ImGui::Button("添加苹果")) {
                    CallStaticMethod<void>(itemDropMgrClass, "SetFoodApple", 食物苹果);
                }
                ImGui::SeparatorText("宝箱系统");
                if (ImGui::Button("添加宝箱")) {
                    CallStaticMethod<void>(itemDropMgrClass, "AddBox");
                }
            }
            ImGui::SeparatorText("物品管理");
            if (!itemManagerInstance) {
                ImGui::TextColored(ImVec4(1,0,0,1), "未获取到 ItemManager 实例");
                if (ImGui::Button("重新获取 ItemManager")) {
                    ItemManager::ResetInstance();
                    itemManagerInstance = ItemManager::GetInstance();
                }
            } else {
                ImGui::RadioButton("使用预设物品", reinterpret_cast<int*>(&useCustomId), 0); 
                ImGui::SameLine();
                ImGui::RadioButton("自定义物品ID", reinterpret_cast<int*>(&useCustomId), 1);
                int currentItemId = 1;
                if (!useCustomId) {
                    ImGui::SetNextItemWidth(350);
                    if (ImGui::BeginCombo("选择物品", itemList[selectedItemIndex].second)) {
                        for (size_t i = 0; i < itemList.size(); i++) {
                            bool isSelected = (selectedItemIndex == i);
                            if (ImGui::Selectable(itemList[i].second, isSelected)) {
                                selectedItemIndex = i;
                            }
                            if (isSelected) {
                                ImGui::SetItemDefaultFocus();
                            }
                        }
                        ImGui::EndCombo();
                    }
                    currentItemId = itemList[selectedItemIndex].first;
                    ImGui::SameLine();
                    ImGui::Text("ID: %d", currentItemId);
                } else {
                    ImGui::SetNextItemWidth(150);
                    ImGui::InputText("##CustomItemId", customItemIdStr, IM_ARRAYSIZE(customItemIdStr));
                    ImGui::SameLine();
                    ImGui::Text("物品ID");
                    currentItemId = atoi(customItemIdStr);
                    if (currentItemId < 0) currentItemId = 1;
                }
                ImGui::SetNextItemWidth(150);
                ImGui::InputInt("物品数量", &itemAddCount);
                itemAddCount = ClampValue(itemAddCount, -999999, 9999999);
                if (ImGui::Button("添加物品", ImVec2(150, 0))) {
                    if (currentItemId > 0) {
                        bool success = ItemManager::AddItem(currentItemId, itemAddCount);
                    }
                }
                ImGui::SameLine();
                if (ImGui::Button("使用物品", ImVec2(150, 0))) {
                    if (currentItemId > 0) {
                        bool success = ItemManager::UseItem(currentItemId, itemAddCount);
                    }
                }
                static int currentItemCount = 0;
                if (ImGui::Button("查询物品数量", ImVec2(150, 0))) {
                    currentItemCount = ItemManager::GetItemCount(currentItemId);
                }
                ImGui::SameLine();
                ImGui::Text("当前数量: %d", currentItemCount);
                ImGui::Separator();
                if (ImGui::TreeNode("批量操作")) {
                    static int batchStartId = 1;
                    static int batchEndId = 10;
                    static int batchCount = 100;
                    ImGui::SetNextItemWidth(100);
                    ImGui::InputInt("起始ID", &batchStartId);
                    ImGui::SameLine();
                    ImGui::SetNextItemWidth(100);
                    ImGui::InputInt("结束ID", &batchEndId);
                    ImGui::SameLine();
                    ImGui::SetNextItemWidth(100);
                    ImGui::InputInt("每个数量", &batchCount);
                    batchStartId = ClampValue(batchStartId, 1, 99999);
                    batchEndId = ClampValue(batchEndId, batchStartId, 99999);
                    batchCount = ClampValue(batchCount, 1, 999999);
                    if (ImGui::Button("批量添加物品", ImVec2(200, 0))) {
                        int successCount = 0;
                        int failCount = 0;
                        for (int id = batchStartId; id <= batchEndId; id++) {
                            if (ItemManager::AddItem(id, batchCount)) {
                                successCount++;
                            } else {
                                failCount++;
                            }
                        }
                    }
                    ImGui::TreePop();
                }
            }
        }
    }
    ImGui::End();
    ImGui::PopStyleVar();
}