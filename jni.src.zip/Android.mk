LOCAL_PATH := $(call my-dir)

include $(CLEAR_VARS)
LOCAL_MODULE            := GlossHook
LOCAL_SRC_FILES         := UnityHook/GlossHook/$(TARGET_ARCH_ABI)/libGlossHook.a
LOCAL_EXPORT_C_INCLUDES := $(LOCAL_PATH)/UnityHook/GlossHook/
include $(PREBUILT_STATIC_LIBRARY)

include $(CLEAR_VARS)
LOCAL_MODULE    := R3v

LOCAL_CFLAGS := -w -s -Wno-error=format-security -fvisibility=hidden -fpermissive -fexceptions
LOCAL_CPPFLAGS := -w -s -Wno-error=format-security -fvisibility=hidden -Werror -std=c++20
LOCAL_CPPFLAGS += -Wno-error=c++11-narrowing -fpermissive -Wall -fexceptions
LOCAL_LDFLAGS += -Wl,--gc-sections,--strip-all, -llog
LOCAL_LDLIBS := -llog -landroid -lEGL -lGLESv3 -lm
LOCAL_ARM_MODE := arm
LOCAL_STATIC_LIBRARIES := GlossHook

LOCAL_C_INCLUDES += $(LOCAL_PATH)
LOCAL_C_INCLUDES += $(LOCAL_PATH)/ImGui
LOCAL_C_INCLUDES += $(LOCAL_PATH)/Include
LOCAL_C_INCLUDES += $(LOCAL_PATH)/UnityHook

LOCAL_SRC_FILES := Main.cpp \
    ImGui/imgui.cpp \
    ImGui/imgui_draw.cpp \
    ImGui/imgui_widgets.cpp \
    ImGui/imgui_tables.cpp \
    ImGui/backends/imgui_impl_opengl3.cpp \
    ImGui/backends/imgui_impl_android.cpp \
    UnityHook/Il2cpp/Il2cpp.cpp \
    UnityHook/Il2cpp/il2cpp-class.cpp \

include $(BUILD_SHARED_LIBRARY)